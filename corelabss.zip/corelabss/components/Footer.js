// components/Footer.js
const Footer = () => {
  return (
    <footer>
      <p>© 2024 CoreLabs. All rights reserved.</p>
    </footer>
  );
};

export default Footer;